package com.zte.exercise

class Hello(name: String){
  def get() = "welcome " + name
}